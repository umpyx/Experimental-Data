#include "cblas_test.h"
int CBLAS_CallFromC;
int RowMajorStrg;

